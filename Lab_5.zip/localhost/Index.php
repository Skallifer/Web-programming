<?php
$res = file_get_contents("Lab_5.JSON");
print($res);

$url = basename(__FILE__);
print($url);
?>