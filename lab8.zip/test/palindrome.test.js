const isPalindrome = require('./palindrome')

test('it detects palindromes', () => {
    expect(isPalindrome('palindrome')).toBe(false)
    expect(isPalindrome('')).toBe(true)
    expect(isPalindrome('a')).toBe(true)
    expect(isPalindrome('gg')).toBe(true)
    expect(isPalindrome('pop')).toBe(true)
    expect(isPalindrome('1212')).toBe(false)
})
test('Detects palindromes (second time)', () =>{
    expect(isPalindrome('racecar')).toBe(true)
    expect(isPalindrome('like')).toBe(false)
    expect(isPalindrome('gog')).toBe(true)
    expect(isPalindrome('tenet')).toBe(true)
    expect(isPalindrome('Mario')).toBe(false)
})
test('Detects palindromes (third)', () =>{
    expect(isPalindrome('madam')).toBe(true)
    expect(isPalindrome('gold')).toBe(false)
    expect(isPalindrome('civic')).toBe(true)
    expect(isPalindrome('deified')).toBe(true)
    expect(isPalindrome('1235')).toBe(false)
})